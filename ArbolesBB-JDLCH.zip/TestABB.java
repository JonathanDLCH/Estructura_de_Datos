import java.util.Scanner;
/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 */
public class TestABB {
    public static void main(String[]args) throws ClaveDuplicadaException{
        int menu,dato;
        Scanner in = new Scanner(System.in);
        ArbolBinario A1 = new ArbolBinario();
        
        System.out.println("0)Salir\n1)Insertar\n2)InOrden\n3)PreOrden\n4)PostOrden");
        menu=in.nextInt();
        while(menu!=0){
            switch(menu){
                case 1:
                    System.out.println("Insertar dato: ");
                    dato=in.nextInt();
                    try{
                        A1.insertarOrdenado(dato);
                    }catch(ClaveDuplicadaException ex){}
                    break;
                case 2: A1.inOrden(A1.getRaiz());break;
                case 3: A1.preOrden(A1.getRaiz());break;
                case 4: A1.postOrden(A1.getRaiz());break;
                default: System.out.println("Numero indefinido");
            }
            System.out.println("0)Salir\n1)Insertar\n2)InOrden\n3)PreOrden\n4)PostOrden");
            menu=in.nextInt();
        }
        
        
    }
}
