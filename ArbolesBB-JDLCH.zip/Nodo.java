/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 */
public class Nodo {
    private Nodo izq,der;
    private int llave;
    
    public Nodo getIzq() {
        return izq;
    }

    public void setIzq(Nodo izq) {
        this.izq = izq;
    }

    public Nodo getDer() {
        return der;
    }

    public void setDer(Nodo der) {
        this.der = der;
    }

    public int getLlave() {
        return llave;
    }

    public void setLlave(int llave) {
        this.llave = llave;
    }
    
    public Nodo(int llave){
        this.llave=llave;
        this.der=null;
        this.izq=null;
    }
}
