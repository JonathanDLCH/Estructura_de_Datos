/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 */
public class ClaveDuplicadaException extends Exception{
    
    public ClaveDuplicadaException() {
        System.out.println("Clave Duplicada");
    }
    
    public ClaveDuplicadaException(String e) {
        super(e);
    }
}
