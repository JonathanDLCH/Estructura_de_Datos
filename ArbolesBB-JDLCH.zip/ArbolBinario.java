/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 */
public class ArbolBinario {
    private Nodo raiz;
    private int nNodos;
    
    public ArbolBinario(){
        raiz=null;
        nNodos=0;
    }
    
    public ArbolBinario(int raiz){
        Nodo padre = new Nodo(raiz);
        this.raiz = padre;
        nNodos=1;
    }
    
    public Nodo getRaiz(){
        return raiz;
    }
    
    public int getNNodos(){
        return nNodos;
    }
    public void setNNodos(int nNodos){
        this.nNodos=nNodos;
    }
    
    public boolean isEmpty(){
        if(raiz==null){
            return true;
        }else{
            return false;
        }
    }
    
    public void insertarOrdenado(int info) throws ClaveDuplicadaException{
        Nodo n = new Nodo(info);        
        if(isEmpty()){
            raiz=n;
        }else{
           insertarOrdenado(raiz,info);
        }        
    }
    private void insertarOrdenado(Nodo n,int info) throws ClaveDuplicadaException{
        if(n.getLlave()==info){
            throw new ClaveDuplicadaException();
        }else{
            if(n.getLlave()>info){
                if(n.getIzq()!=null){
                    insertarOrdenado(n.getIzq(),info);
                }else{
                    n.setIzq(new Nodo(info));
                }
            }else{
                if(n.getDer()!=null){
                    insertarOrdenado(n.getDer(),info);
                }else{
                    n.setDer(new Nodo(info));
                }
            }
        }
    }
    
    public String preOrden(Nodo raiz){
        String preOrden="";
        if(raiz!=null){
            preOrden+=raiz.getLlave();
            System.out.println(preOrden);
            preOrden(raiz.getIzq());
            preOrden(raiz.getDer());
        }
        return preOrden;
    }
    
    public String inOrden(Nodo raiz){
        String inOrden="";
        if(raiz!=null){
            inOrden(raiz.getIzq());
            inOrden+=raiz.getLlave();
            System.out.println(inOrden);
            inOrden(raiz.getDer());
        }
        return inOrden;
    }
    
    public String postOrden(Nodo raiz){
        String postOrden="";
        if(raiz!=null){
            postOrden(raiz.getIzq());
            postOrden(raiz.getDer());
            postOrden+=raiz.getLlave();
            System.out.println(postOrden);
        }
        return postOrden;
    }
    
    private boolean busqueda(int search,Nodo n){
        int flag=0;
        if(isEmpty()){
            System.out.println("Arbol vacio");
        }else{
            if(n.getLlave()==search){
                flag=1;
            }else{
                if(search<n.getLlave()){
                    busqueda(search,n.getIzq());
                }else{
                    busqueda(search,n.getDer());
                }
            }
        }
        if(flag==1){
            return true;
        }else{
            return false;
        }
    }
}
