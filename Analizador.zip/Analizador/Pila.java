/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ignacio Diaz
 */
public class Pila {
    
    private int tam;
    private int tope;
    private char elementos[];

    public Pila(){
        this.tam=10;
        this.elementos= new char[tam];
        this.tope=-1;
    }
    public Pila(int t) { 
        this.tam=t;
        this.elementos=new char[tam];
        this.tope=-1;
    }
    public boolean estaVacia(){
        if(tope == -1){
           return true;
        }else{
          return false;
        }
    }
    public boolean estaLlena(){
        if(tope == (tam-1)){
           return true;
        }else{
          return false;
        }
    }
    public void push(char n){
        if(estaLlena()== false){
          elementos[tope+1]=n;
          tope++;
         }else
            System.out.println("LA PILA ESTA LLENA");
    }
    public char pop()throws VaciaException{
        char n;
        if(estaVacia()== false){
          n = elementos[tope];
          tope--;
          return n;
        }else{
            
         throw new VaciaException("La pila esta vacia"); 
            
        }
    }
    public char peek()throws VaciaException{
    
    if(estaVacia()== false){
          char n = elementos[tope];
         
          return n;
        }else{
            throw new VaciaException("La pila esta vacia"); 
        }    
    }
    public void mostrar()throws VaciaException{
        if(estaVacia()== false){
          for(int i = tope; i >= 0; i--){
        System.out.println("|"+elementos[i]+"|");
    }
        }else{
            throw new VaciaException("La pila esta vacia"); 
        } 
    }
    
   
}
