/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ignacio Diaz Romero
 */
public class Analizador {
        Pila p;
        int i;
        
        public Analizador(){
        p=new Pila();
        }
        
        public boolean analizarSimbolos(String cad) throws VaciaException{
            boolean x=true;
            for(i=0;i<cad.length();i++){
                if(esSimApertura(cad.charAt(i)))
                    p.push(cad.charAt(i));
                else{
                    if(!p.estaVacia()){
                        if(esSimTerminacion(cad.charAt(i)))
                            x=estanEmparejados(p.pop(),cad.charAt(i));
                    }
                    else{
                        if(esSimTerminacion(cad.charAt(i))){
                            System.out.println("Simbolos no  equilibrados");
                            return false;
                        }
                       
                    }
                }
               if(!x)
                   
                return x;
            }
            System.out.println("Simbolos equilibrados");
            return x;
        }
        
        public boolean esSimApertura(char s){
        if(s=='(' || s=='[' || s=='{' || s=='<'){
            return true;
        }else
            return false;
    }
    public boolean esSimTerminacion(char s){
        if(s==')' || s==']' || s=='}' || s=='>'){
            return true;
        }else
            return false;
    }
    public boolean estanEmparejados(char sa,char st){
        if((sa=='(' && st==')')||(sa=='{' && st=='}')||(sa=='[' && st==']')||(sa=='<' && st=='>')){
            return true;
        }else{
           return false;
        }  
    }
    
    
}
