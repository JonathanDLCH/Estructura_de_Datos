/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ignacio Diaz
 */
public class VaciaException extends Exception {

    
    public VaciaException() {
    }

    
    public VaciaException(String msg) {
        super(msg);
    }
}
