
import java.util.Scanner;
//EQUIPO:
//IGNACIO DIAZ ROMERO 201734055
//JONATHAN DE LA CRUZ 201731754
//GABRIELA CORONA 

public class TestAnalizador {
    public static void main(String[]args) throws VaciaException{
        Scanner entrada = new Scanner(System.in);
        Pila miPila = new Pila();
        Analizador miAnalizador = new Analizador();
        String simbolos;
        int opc=0;
        
        do{
           System.out.println("Ingrese una cadena de simbolos: ");
            simbolos= entrada.nextLine();
            if(miAnalizador.analizarSimbolos(simbolos))
                System.out.println("SIMBOLOS EQUILIBRADOS");
            else
                System.out.println("SIMBOLOS NO EQUILIBRADOS");
            System.out.println("1)Ingresar nueva cadena\n2)Salir");
            opc = entrada.nextInt();
            entrada.nextLine();
        }while(opc != 2);
    }
}
