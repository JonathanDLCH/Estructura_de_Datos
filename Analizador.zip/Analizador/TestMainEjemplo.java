//EQUIPO:
//IGNACIO DIAZ ROMERO 201734055
//JONATHAN DE LA CRUZ 201731754
//GABRIELA CORONA PAPALOTZI 201736471
public class TestMainEjemplo {
    public static void main(String [] args) throws VaciaException {
 Analizador a = new Analizador();
 System.out.println("([<{ }>])" + a.analizarSimbolos("([<{ }>])"));
 System.out.println("([(]) : "+a.analizarSimbolos("([(])"));
 System.out.println("([[<{ }>) : "+a.analizarSimbolos("([[<{ }>)"));
 System.out.println("((5+2)-(1+4)) : "+a.analizarSimbolos("((5+2)-(1+4))"));
 System.out.println("][)(: "+a.analizarSimbolos("][)("));
    }
}
