/**
 *
 * @author Jonathan De La Cruz Huerta
 */
public class VaciaException extends Exception {

    
    public VaciaException() {
    }

    
    public VaciaException(String e) {
        super(e);
    }
}
