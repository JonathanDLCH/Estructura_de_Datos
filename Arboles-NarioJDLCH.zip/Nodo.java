/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 */
public class Nodo {
    String valor;
    int nHijos;
    Nodo hijos[],hijosT[];
    
    public Nodo(String valor){
        this.valor=valor;
        this.nHijos=0;
    }
    
    public void copiarHijos(){
        hijosT=new Nodo[nHijos+1];
        for(int i=0;i<this.nHijos;i++){
            hijosT[i]=hijos[i];
        }
    }
    
    public void aumentarHijo(Nodo nodo){
        copiarHijos();
        hijosT[this.nHijos]=nodo;
        hijos=hijosT;
        this.nHijos++;
    }
    
    public String getDato(){
        return valor;
    }
    
    public void setDato(String valor){
        this.valor=valor;
    }
}
