/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 * Implementacion de un arbol a partir de array.
 * En esta implementacion nos permite crear un arbol, agregar nodos o hijos, y recorrer el arbol binario de diferentes maneras.
 */
public class ArbolMulticamino {
    Nodo raiz;
    
    public ArbolMulticamino(){
        raiz=null;
    }
    public ArbolMulticamino(String dato){
        raiz= new Nodo(dato);
    }
    
    public Nodo insertarRaiz(String dato){
        raiz= new Nodo(dato);
        return raiz;
    }
    
    public void insertar(Nodo nodo,String dato,String padre){
        Nodo nuevo = new Nodo(dato);
        
        if(nodo.getDato().equals(padre)){
            nodo.aumentarHijo(nuevo);
        }else{
            for(int i=0;i<nodo.nHijos;i++){
                if(nodo.hijos[i].getDato().equals(padre)){
                    nodo.hijos[i].aumentarHijo(nuevo);
                }else{
                    insertar(nodo.hijos[i],dato,padre);
                }
            }
        }
    }
    
    public void verHijos(Nodo nodo){
        for(int i=0;i<nodo.nHijos;i++){
            //nodo.hijos[i].verNodo();
            System.out.println(nodo.hijos[i].getDato());
            verHijos(nodo.hijos[i]);
        }
    }
    
    public void preOrden(Nodo nodo){
        if(nodo.getDato().equals(raiz.getDato())){
            System.out.println(nodo.getDato());
        }
        for(int i=0;i<nodo.nHijos;i++){
            System.out.println(nodo.hijos[i].getDato());
            preOrden(nodo.hijos[i]);
        }
    }
    
    public void postOrden(Nodo nodo){
        if(nodo.hijos!=null){
            for(Nodo n:nodo.hijos){
                postOrden(n);
            }
        }
        System.out.println(nodo.getDato());
    }
    
    public void niveles() throws VaciaException{
        Nodo nodo=null;
        Cola queue = new Cola();
        queue.queue(this.raiz);
        while(!queue.estaVacia()){
            nodo=queue.dequeue();
            if(nodo!=null){
                System.out.println(nodo.getDato());
                if(nodo.nHijos>0){
                    for(Nodo n:nodo.hijos){
                        queue.queue(n);
                    }
                }
            }
        }
    }
    
}
