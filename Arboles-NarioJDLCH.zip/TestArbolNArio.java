import java.util.Scanner;

/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 */
public class TestArbolNArio {
    public static void main(String[]args){
        Scanner in= new Scanner(System.in);
        int menu;
        String dato,padre,hijo;       
        ArbolMulticamino arbol1;
        
        System.out.println("Ingrese la raiz: ");
        dato=in.nextLine();
        arbol1 = new ArbolMulticamino(dato);
        
        do{
            System.out.println("Añadiendo hijos.");
            System.out.println("Dato hijo: ");
            hijo=in.nextLine();
            System.out.println("Padre: ");
            padre=in.nextLine();
            arbol1.insertar(arbol1.raiz, hijo, padre);
            
            System.out.println("1)Nuevo hijo 0)Salir");
            menu=in.nextInt();
            dato=in.nextLine();
        }while(menu!=0);
        
        do{
            System.out.println("Tipo de recorrido:\n1)Preorden\n2)Pos-orden\n3)Niveles\n0)Salir");
            menu=in.nextInt();
            switch(menu){
                case 1: arbol1.preOrden(arbol1.raiz);
                    break;
                case 2: arbol1.postOrden(arbol1.raiz);
                    break;
                case 3: try{arbol1.niveles();}catch(Exception ae){}
                    break;
                case 0: System.out.println("Gracias...");
                    break;
                default: System.out.println("Error");
            }
        }while(menu!=0);        
    }
}
