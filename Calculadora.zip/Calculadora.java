
import javax.swing.JOptionPane;

/**
 * @author Yalu
 */
public class Calculadora {
   
    private Pila pDig = new Pila(), pOper= new Pila();
    
    //Constructor
    Calculadora(){
        
    }

    public String convertirPosFijo(String infijo) throws VaciaException{
        String postfijo = ""; //Cadena de salida,aqui concatenamos con el resultado
        int i=0;
        
        while(i < infijo.length()) {
            if(Character.isDigit(infijo.charAt(i))){
                //pDig.push(infijo.charAt(i));// obtiene el operando para mandarlo a la salida 
                postfijo= postfijo+infijo.charAt(i); //Aqui concatena a la cadena postfijo
                i++;
            }
            else
            {
                if(pOper.estaVacia()){
                    pOper.push(infijo.charAt(i));
                    i++;
                }else{
                    //analizamos prioridades de operadores
                    while(!pOper.estaVacia() && (prioridad(infijo.charAt(i)))<=prioridad(pOper.peek())){
                        postfijo=postfijo+pOper.pop();
                    }
                    pOper.push(infijo.charAt(i));
                    i++;
                }
            }
        }
        while(!pOper.estaVacia()){
            postfijo= postfijo+pOper.pop();
        }
        return postfijo;
    }

    public int  evaluar(String postfijo) throws VaciaException{
        int res=0,i=0,der=0,izq=0;
        
        while(i< postfijo.length()){
            if(Character.isDigit(postfijo.charAt(i))){
                pDig.push(postfijo.charAt(i));
                i++;
            }else{
                der=(int)pDig.pop()-48;
                izq=(int)pDig.pop()-48;
                if(postfijo.charAt(i)=='+'){    
                    res=izq+der;
                    pDig.push((char) res);
                    i++;
                }else{
                    if(postfijo.charAt(i)=='-'){
                        res =izq-der;
                        pDig.push((char) res);
                        i++;
                    }else{
                        if(postfijo.charAt(i)=='*'){
                            res = (int)izq * (int)der;
                            pDig.push((char) res);
                            i++;
                        }else{
                            if(postfijo.charAt(i)=='/'){
                                res = (int)izq / (int)der;
                                pDig.push((char) res);
                                i++;
                            }else{
                                if(postfijo.charAt(i)=='∧'){
                                    res = (int) Math.pow(izq, der);
                                    pDig.push((char) res);
                                    i++;
                                }else{
                                    JOptionPane.showMessageDialog(null,"Signo indefinido");
                                }
                            }
                        }
                    }
                }
                
            }
        }
        res=pDig.pop();
        return res;
    }
    
    public int prioridad(char s){
        if(s == '∧'){
            return 3;
        }else{
            if(s == '*'|| s =='/'){
                return 2;
            }else{
                if(s == '+'|| s =='-'){
                    return 1;
                }else{
                    return 0;
                }
            }
        }
    }
}
