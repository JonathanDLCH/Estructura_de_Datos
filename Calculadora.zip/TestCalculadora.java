import javax.swing.*;

/**
 *
 * @author Yalu
 */
public class TestCalculadora {

    public static void main(String args[]){

        Calculadora cal = new Calculadora();
        CalculadoraVista marco = new CalculadoraVista(cal); //Se pasa cal para que pueda usar sus metodos.
        marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marco.setLocationRelativeTo(null);
        marco.setVisible(true);
    }
}
