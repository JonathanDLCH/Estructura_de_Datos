
import javax.swing.JOptionPane;

public class Recorrido extends javax.swing.JFrame {   
    
    Archivo a1 = new Archivo();
    Grafo rolloG = a1.retornarDatosGrafo();
    GrafoUI mapa  = new GrafoUI(rolloG,a1);
    int inicio;
    int Fin;
    /**
     * Creates new form CheckOut
     */
    public Recorrido() {
        initComponents();
        borrar();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        jLabelLogo = new javax.swing.JLabel();
        jLabelTipoR = new javax.swing.JLabel();
        jLabelIndicacion = new javax.swing.JLabel();
        jLabelInicio = new javax.swing.JLabel();
        jLabelFinal = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBoxInicio = new javax.swing.JComboBox<>();
        jComboBoxFin = new javax.swing.JComboBox<>();
        jLabelLaCascada = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabelElRollo = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabelLasOlas = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabelSurfing = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        try {
            jButtonMapa =(javax.swing.JButton)java.beans.Beans.instantiate(getClass().getClassLoader(), "CheckOut_jButton3");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
        jButtonRegresar = new javax.swing.JButton();

        jTextField2.setText("jTextField2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabelLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/elrollologo.png"))); // NOI18N

        jLabelTipoR.setText("Tipo de recorrido");

        jLabelIndicacion.setText("Selecciona el nombre de la atraccion/servicio");

        jLabelInicio.setText("Donde te encuentras:");

        jLabelFinal.setText("A donde quieres ir:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona tipo de recorrido", "¡Conoce todas las atracciones!", "¡De un punto a otro!", "Seccion \"La cascada\"", "Seccion \"El rollo\"", "Seccion \"Las olas\"", "Seccion \"Surfing\"" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jComboBoxInicio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona punto de inicio", "Fosa de clavados", "Kamilancha", "MiniKamikaze ", "Río lento", "Tobogán de curas", "Isla Infantil", "Area Infantil Interactiva", "Alberca de olas", "Aquatubo", "Alberca ballena", "Bubbatubo", "Racer", "Puente colgantel", "Aqualoop", "Stuka", "Kamikaze", "Toborruedas", "Tobogán de Curvas", "Tobogán Vertical Droop", "Alberca de Olas ", "Isla Infantil", "Rio con Olas", "Ola para Surfear", "Revolcadero", "Las boas ", "El péndulo", "Torbellino", "Backflash", "Mamut", "Isla Infantil", "Articulos de playa", "Comida rápida", "Restaurante \"El rollo\"", "MiniSuper", "Restaurante \"Las olas\"", "Fuente de sodas", "Parrillas", "Restaurante \"Las olas\"" }));
        jComboBoxInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxInicioActionPerformed(evt);
            }
        });

        jComboBoxFin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona punto de final", "Alberca de olas", "Aquatubo", "Alberca ballena", "Bubbatubo", "Racerl", "Puente colgantel", "Fosa de clavados", "Kamilancha", "MiniKamikaze ", "Río lento", "Tobogán de curas", "Isla Infantil", "Area Infantil Interactiva", "Aqualoop", "Stuka", "Kamikaze", "Toborruedas", "Tobogán de Curvas", "Tobogán Vertical Droop", "Alberca de Olas ", "Isla Infantil", "Rio con Olas", "Ola para Surfear", "Revolcadero", "Las boas ", "El péndulo", "Torbellino", "Backflash", "Mamut", "Isla Infantil", "Articulos de playa", "Comida rápida", "Restaurante \"El rollo\"", "MiniSuper", "Restaurante \"Las olas\"", "Fuente de sodas", "Parrillas", "Restaurante \"Las olas\"" }));
        jComboBoxFin.setToolTipText("");
        jComboBoxFin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxFinActionPerformed(evt);
            }
        });

        jLabelLaCascada.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabelLaCascada.setText("La cascada");

        jLabel1.setText("Alberca de olas");

        jLabel2.setText("Aquatubol");

        jLabel3.setText("Alberca ballena");

        jLabel4.setText("Bubbatubo");

        jLabel5.setText("Racer");

        jLabel6.setText("Puente colgante");

        jLabel7.setText("Articulos de playa");

        jLabel8.setText("Comida rápida");

        jLabel9.setText("Fuente de sodas");

        jLabel10.setText("Parrillas");

        jLabelElRollo.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabelElRollo.setText("El rollo");

        jLabel11.setText("Fosa de clavados");

        jLabel12.setText("Kamilancha");

        jLabel13.setText("MiniKamikaze");

        jLabel14.setText("Río lento");

        jLabel15.setText("Tobogan de curvas");

        jLabel16.setText("Isla Infantil");

        jLabel17.setText("Area Infantil Interactiva");

        jLabel18.setText("Articulos de playa");

        jLabel19.setText("Comida rápida");

        jLabel20.setText("Fuente de sodas");

        jLabel21.setText("Parrillas");

        jLabel22.setText("Restaurante \"El rollo\"");

        jLabel23.setText("Restaurante \"Azaleas\"");

        jLabel24.setText("Mini Super");

        jLabelLasOlas.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabelLasOlas.setText("Las olas");

        jLabel25.setText("Aqualoop");

        jLabel26.setText("Stuka");

        jLabel27.setText("Kamikaze");

        jLabel29.setText("Toborruedas");

        jLabel30.setText("Tobógan de Curvas");

        jLabel31.setText("Vertical Droop");

        jLabel28.setText("Alberca de olas");

        jLabel32.setText("Isla Infantil");

        jLabel33.setText("Articulos de playa");

        jLabel34.setText("Comida rápida");

        jLabel35.setText("Fuente de sodas");

        jLabel36.setText("Parrillas");

        jLabel37.setText("Restaurante \"Las olas\"");

        jLabelSurfing.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabelSurfing.setText("Surfing");

        jLabel38.setText("Rio con Olas");

        jLabel39.setText("Ola para Surfear");

        jLabel40.setText("Revolcadero");

        jLabel41.setText("Las boas");

        jLabel42.setText(" El péndulo");

        jLabel43.setText("Torbellino");

        jLabel44.setText("Backflash");

        jLabel45.setText("Mamut");

        jLabel46.setText("Isla Infantil");

        jButtonMapa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMapaActionPerformed(evt);
            }
        });

        jButtonRegresar.setText("Regresar");
        jButtonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabelLogo))
                    .addComponent(jLabelTipoR)
                    .addComponent(jLabelIndicacion)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelInicio)
                            .addComponent(jLabelFinal)
                            .addComponent(jButtonRegresar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBoxInicio, 0, 1, Short.MAX_VALUE)
                            .addComponent(jComboBoxFin, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelLaCascada, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel5))))
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelElRollo)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel18)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel21)
                                    .addComponent(jLabel22)
                                    .addComponent(jLabel23))
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel37)
                                    .addComponent(jLabel36)
                                    .addComponent(jLabel35)
                                    .addComponent(jLabel34)
                                    .addComponent(jLabel33)
                                    .addComponent(jLabel31)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel29)
                                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel32)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel25)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel38))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabelLasOlas)
                                            .addGap(72, 72, 72)
                                            .addComponent(jLabelSurfing)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel30)
                                        .addGap(42, 42, 42)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel43)
                                            .addComponent(jLabel40)
                                            .addComponent(jLabel39)
                                            .addComponent(jLabel41)
                                            .addComponent(jLabel42)
                                            .addComponent(jLabel45)
                                            .addComponent(jLabel44)
                                            .addComponent(jLabel46)))))
                            .addComponent(jLabel24))
                        .addGap(33, 33, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonMapa)
                        .addGap(30, 30, 30))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabelLogo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelTipoR))
                        .addGap(41, 41, 41)
                        .addComponent(jLabelIndicacion)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBoxInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelInicio))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBoxFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelFinal)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelLaCascada, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelElRollo)
                            .addComponent(jLabelLasOlas)
                            .addComponent(jLabelSurfing))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel25)
                            .addComponent(jLabel38))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel12)
                            .addComponent(jLabel26)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel13)
                            .addComponent(jLabel27)
                            .addComponent(jLabel40))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel41))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel4)
                                .addComponent(jLabel14)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel15)
                            .addComponent(jLabel29)
                            .addComponent(jLabel42))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel16)
                            .addComponent(jLabel30)
                            .addComponent(jLabel43))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel17)
                            .addComponent(jLabel31)
                            .addComponent(jLabel44))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jLabel18)
                            .addComponent(jLabel32)
                            .addComponent(jLabel45))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel33)
                            .addComponent(jLabel46))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel20)
                                .addComponent(jLabel34)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addComponent(jLabel35))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22)
                            .addComponent(jLabel36))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel23)
                            .addComponent(jLabel37))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel24)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButtonRegresar)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButtonMapa)
                        .addGap(40, 40, 40))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
           //1. TODO
           if(jComboBox1.getSelectedIndex()==0)borrar();
        if(jComboBox1.getSelectedIndex()==1){
            borrar();
            jLabelElRollo.setVisible(true);
            jLabelSurfing.setVisible(true);
            jLabelLasOlas.setVisible(true);
            jLabelLaCascada.setVisible(true);
            jLabel1.setVisible(true);
            jLabel2.setVisible(true);
            jLabel3.setVisible(true);
            jLabel4.setVisible(true);
            jLabel5.setVisible(true);
            jLabel6.setVisible(true);
            jLabel7.setVisible(true);
            jLabel8.setVisible(true);
            jLabel9.setVisible(true);
            jLabel10.setVisible(true);
            jLabel11.setVisible(true);
            jLabel12.setVisible(true);
            jLabel13.setVisible(true);
            jLabel14.setVisible(true);
            jLabel15.setVisible(true);
            jLabel16.setVisible(true);
            jLabel17.setVisible(true);
            jLabel18.setVisible(true);
            jLabel19.setVisible(true);
            jLabel20.setVisible(true);
            jLabel21.setVisible(true);
            jLabel22.setVisible(true);
            jLabel23.setVisible(true);
            jLabel24.setVisible(true);
            jLabel25.setVisible(true);
            jLabel26.setVisible(true);
            jLabel27.setVisible(true);
            jLabel29.setVisible(true);
            jLabel30.setVisible(true);
            jLabel31.setVisible(true);
            jLabel28.setVisible(true);
            jLabel32.setVisible(true);
            jLabel33.setVisible(true);
            jLabel34.setVisible(true);
            jLabel35.setVisible(true);
            jLabel36.setVisible(true);
            jLabel37.setVisible(true);
            jLabel38.setVisible(true);
            jLabel39.setVisible(true); 
            jLabel40.setVisible(true);
            jLabel41.setVisible(true);
            jLabel42.setVisible(true);
            jLabel43.setVisible(true);
            jLabel44.setVisible(true);
            jLabel45.setVisible(true);
            jLabel46.setVisible(true);
        }
        //De un punto a otro
        if(jComboBox1.getSelectedIndex()==2){
            borrar();
            jComboBoxFin.setVisible(true);
            jLabelLaCascada.setVisible(true);
            jLabelFinal.setVisible(true);
            jLabelElRollo.setVisible(true);
            jLabelSurfing.setVisible(true);
            jLabelLasOlas.setVisible(true);
            inicio();
        }
        //La cascada
        if(jComboBox1.getSelectedIndex()==3){
            borrar();
            jLabelLaCascada.setVisible(true);
            jLabel1.setVisible(true);
            jLabel2.setVisible(true);
            jLabel3.setVisible(true);
            jLabel4.setVisible(true);
            jLabel5.setVisible(true);
            jLabel6.setVisible(true);
            jLabel7.setVisible(true);
            jLabel8.setVisible(true);
            jLabel9.setVisible(true);
            jLabel10.setVisible(true);
        }
        //El rollo
        if(jComboBox1.getSelectedIndex()==4){
            borrar();
            jLabelElRollo.setVisible(true);
            jLabel11.setVisible(true);
            jLabel12.setVisible(true);
            jLabel13.setVisible(true);
            jLabel14.setVisible(true);
            jLabel15.setVisible(true);
            jLabel16.setVisible(true);
            jLabel17.setVisible(true);
            jLabel18.setVisible(true);
            jLabel19.setVisible(true);
            jLabel20.setVisible(true);
            jLabel21.setVisible(true);
            jLabel22.setVisible(true);
            jLabel23.setVisible(true);
            jLabel24.setVisible(true);
        }
        //Las olas
        if(jComboBox1.getSelectedIndex()==5){
            borrar();
            jLabelLasOlas.setVisible(true);
            jLabel25.setVisible(true);
            jLabel26.setVisible(true);
            jLabel27.setVisible(true);
            jLabel29.setVisible(true);
            jLabel30.setVisible(true);
            jLabel31.setVisible(true);
            jLabel28.setVisible(true);
            jLabel32.setVisible(true);
            jLabel33.setVisible(true);
            jLabel34.setVisible(true);
            jLabel35.setVisible(true);
            jLabel36.setVisible(true);
            jLabel37.setVisible(true);
        }
        //Surfing
        if(jComboBox1.getSelectedIndex()==6){
            borrar();
            jLabelSurfing.setVisible(true);
            jLabel38.setVisible(true);
            jLabel39.setVisible(true); 
            jLabel40.setVisible(true);
            jLabel41.setVisible(true);
            jLabel42.setVisible(true);
            jLabel43.setVisible(true);
            jLabel44.setVisible(true);
            jLabel45.setVisible(true);
            jLabel46.setVisible(true);          
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBoxInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxInicioActionPerformed

    private void jComboBoxFinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxFinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxFinActionPerformed

    private void jButtonMapaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMapaActionPerformed
        inicio();
        mapa.setVisible(true);
        repaint();
    }//GEN-LAST:event_jButtonMapaActionPerformed

    private void jButtonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRegresarActionPerformed
        Video obj = new Video();
        obj.setLocationRelativeTo(null);
        obj.setResizable(true);
        obj.setVisible(true);
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButtonRegresarActionPerformed

     void borrar(){
            jLabelIndicacion.setVisible(true);
            jLabelInicio.setVisible(true);
            jLabelLaCascada.setVisible(false);
            jLabelFinal.setVisible(false);
            jLabel1.setVisible(false);
            jLabel2.setVisible(false);
            jLabel3.setVisible(false);
            jLabel4.setVisible(false);
            jLabel5.setVisible(false);
            jLabel6.setVisible(false);
            jLabel7.setVisible(false);
            jLabel8.setVisible(false);
            jLabel9.setVisible(false);
            jLabel10.setVisible(false);
            jLabelElRollo.setVisible(false);
            jLabel11.setVisible(false);
            jLabel12.setVisible(false);
            jLabel13.setVisible(false);
            jLabel14.setVisible(false);
            jLabel15.setVisible(false);
            jLabel16.setVisible(false);
            jLabel17.setVisible(false);
            jLabel18.setVisible(false);
            jLabel19.setVisible(false);
            jLabel20.setVisible(false);
            jLabel21.setVisible(false);
            jLabel22.setVisible(false);
            jLabel23.setVisible(false);
            jLabel24.setVisible(false);
            jLabelLasOlas.setVisible(false);
            jLabel25.setVisible(false);
            jLabel26.setVisible(false);
            jLabel27.setVisible(false);
            jLabel29.setVisible(false);
            jLabel30.setVisible(false);
            jLabel31.setVisible(false);
            jLabel28.setVisible(false);
            jLabel32.setVisible(false);
            jLabel33.setVisible(false);
            jLabel34.setVisible(false);
            jLabel35.setVisible(false);
            jLabel36.setVisible(false);
            jLabel37.setVisible(false);
            jLabelSurfing.setVisible(false);
            jLabel38.setVisible(false);
            jLabel39.setVisible(false);
            jLabel40.setVisible(false);
            jLabel41.setVisible(false);
            jLabel42.setVisible(false);
            jLabel43.setVisible(false);
            jLabel44.setVisible(false);
            jLabel45.setVisible(false);
            jLabel46.setVisible(false);
            jComboBoxInicio.setVisible(true);
            jComboBoxFin.setVisible(false);
    }
     void inicio(){
         if(jComboBoxInicio.getSelectedIndex()==1){
             inicio=1;
         }
         if(jComboBoxInicio.getSelectedIndex()==2){
             inicio=2;
         }
         if(jComboBoxInicio.getSelectedIndex()==3){
             inicio=3;
         }
         if(jComboBoxInicio.getSelectedIndex()==4){
             inicio=4;
         }
         if(jComboBoxInicio.getSelectedIndex()==5){
             inicio=5;
         }
         if(jComboBoxInicio.getSelectedIndex()==6){
             inicio=6;
         }
         if(jComboBoxInicio.getSelectedIndex()==7){
             inicio=7;
         }
         if(jComboBoxInicio.getSelectedIndex()==8){
             inicio=8;
         }
         if(jComboBoxInicio.getSelectedIndex()==9){
             inicio=9;
         }
         if(jComboBoxInicio.getSelectedIndex()==10){
             inicio=10;
         }
         if(jComboBoxInicio.getSelectedIndex()==11){
             inicio=11;
         }
         if(jComboBoxInicio.getSelectedIndex()==12){
             inicio=12;
         }
         if(jComboBoxInicio.getSelectedIndex()==13){
             inicio=13;
         }
         if(jComboBoxInicio.getSelectedIndex()==14){
             inicio=14;
         }
         if(jComboBoxInicio.getSelectedIndex()==15){
             inicio=15;
         }
         if(jComboBoxInicio.getSelectedIndex()==16){
             inicio=16;
         }
         if(jComboBoxInicio.getSelectedIndex()==17){
             inicio=17;
         }
         if(jComboBoxInicio.getSelectedIndex()==18){
             inicio=18;
         }
         if(jComboBoxInicio.getSelectedIndex()==19){
             inicio=19;
         }
         if(jComboBoxInicio.getSelectedIndex()==20){
             inicio=20;
         }
         if(jComboBoxInicio.getSelectedIndex()==21){
             inicio=21;
         }
         if(jComboBoxInicio.getSelectedIndex()==22){
             inicio=22;
         }
         if(jComboBoxInicio.getSelectedIndex()==23){
             inicio=23;
         }
         if(jComboBoxInicio.getSelectedIndex()==24){
             inicio=24;
         }
         if(jComboBoxInicio.getSelectedIndex()==25){
             inicio=25;
         }
         if(jComboBoxInicio.getSelectedIndex()==26){
             inicio=26;
         }
         if(jComboBoxInicio.getSelectedIndex()==27){
             inicio=27;
         }
         if(jComboBoxInicio.getSelectedIndex()==28){
             inicio=28;
         }
         if(jComboBoxInicio.getSelectedIndex()==29){
             inicio=29;
         }
         if(jComboBoxInicio.getSelectedIndex()==30){
             inicio=30;
         }
         if(jComboBoxInicio.getSelectedIndex()==31){
             inicio=31;
         }
         if(jComboBoxInicio.getSelectedIndex()==32){
             inicio=32;
         }
         if(jComboBoxInicio.getSelectedIndex()==33){
             inicio=33;
         }
         if(jComboBoxInicio.getSelectedIndex()==34){
             inicio=34;
         }
         if(jComboBoxInicio.getSelectedIndex()==35){
             inicio=35;
         }
         if(jComboBoxInicio.getSelectedIndex()==36){
             inicio=36;
         }
         if(jComboBoxInicio.getSelectedIndex()==37){
             inicio=37;
         }
         if(jComboBoxInicio.getSelectedIndex()==38){
             inicio=38;
         }
         if(jComboBoxInicio.getSelectedIndex()==39){
             inicio=39;
         }

     }
     
     void Fin(){
         if(jComboBoxFin.getSelectedIndex()==1){
             Fin=1;
         }
         if(jComboBoxFin.getSelectedIndex()==2){
             Fin=2;
         }
         if(jComboBoxFin.getSelectedIndex()==3){
             Fin=3;
         }
         if(jComboBoxFin.getSelectedIndex()==4){
             Fin=4;
         }
         if(jComboBoxFin.getSelectedIndex()==5){
             Fin=5;
         }
         if(jComboBoxFin.getSelectedIndex()==6){
             Fin=6;
         }
         if(jComboBoxFin.getSelectedIndex()==7){
             Fin=7;
         }
         if(jComboBoxFin.getSelectedIndex()==8){
             Fin=8;
         }
         if(jComboBoxFin.getSelectedIndex()==9){
             Fin=9;
         }
         if(jComboBoxFin.getSelectedIndex()==10){
             Fin=10;
         }
         if(jComboBoxFin.getSelectedIndex()==11){
             Fin=11;
         }
         if(jComboBoxFin.getSelectedIndex()==12){
             Fin=12;
         }
         if(jComboBoxFin.getSelectedIndex()==13){
             Fin=13;
         }
         if(jComboBoxFin.getSelectedIndex()==14){
             Fin=14;
         }
         if(jComboBoxFin.getSelectedIndex()==15){
             Fin=15;
         }
         if(jComboBoxFin.getSelectedIndex()==16){
             Fin=16;
         }
         if(jComboBoxFin.getSelectedIndex()==17){
             Fin=17;
         }
         if(jComboBoxFin.getSelectedIndex()==18){
             Fin=18;
         }
         if(jComboBoxFin.getSelectedIndex()==19){
             Fin=19;
         }
         if(jComboBoxFin.getSelectedIndex()==20){
             Fin=20;
         }
         if(jComboBoxFin.getSelectedIndex()==21){
             Fin=21;
         }
         if(jComboBoxFin.getSelectedIndex()==22){
             Fin=22;
         }
         if(jComboBoxFin.getSelectedIndex()==23){
             Fin=23;
         }
         if(jComboBoxFin.getSelectedIndex()==24){
             Fin=24;
         }
         if(jComboBoxFin.getSelectedIndex()==25){
             Fin=25;
         }
         if(jComboBoxFin.getSelectedIndex()==26){
             Fin=26;
         }
         if(jComboBoxFin.getSelectedIndex()==27){
             Fin=27;
         }
         if(jComboBoxFin.getSelectedIndex()==28){
             Fin=28;
         }
         if(jComboBoxFin.getSelectedIndex()==29){
             Fin=29;
         }
         if(jComboBoxFin.getSelectedIndex()==30){
             Fin=30;
         }
         if(jComboBoxFin.getSelectedIndex()==31){
             Fin=31;
         }
         if(jComboBoxFin.getSelectedIndex()==32){
             Fin=32;
         }
         if(jComboBoxFin.getSelectedIndex()==33){
             Fin=33;
         }
         if(jComboBoxFin.getSelectedIndex()==34){
             Fin=34;
         }
         if(jComboBoxFin.getSelectedIndex()==35){
             Fin=35;
         }
         if(jComboBoxFin.getSelectedIndex()==36){
             Fin=36;
         }
         if(jComboBoxFin.getSelectedIndex()==37){
             Fin=37;
         }
         if(jComboBoxFin.getSelectedIndex()==38){
             Fin=38;
         }
         if(jComboBoxFin.getSelectedIndex()==39){
             Fin=39;
         }

     }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Recorrido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Recorrido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Recorrido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Recorrido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Recorrido().setVisible(true);
            }
        });
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonMapa;
    private javax.swing.JButton jButtonRegresar;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBoxFin;
    private javax.swing.JComboBox<String> jComboBoxInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelElRollo;
    private javax.swing.JLabel jLabelFinal;
    private javax.swing.JLabel jLabelIndicacion;
    private javax.swing.JLabel jLabelInicio;
    private javax.swing.JLabel jLabelLaCascada;
    private javax.swing.JLabel jLabelLasOlas;
    private javax.swing.JLabel jLabelLogo;
    private javax.swing.JLabel jLabelSurfing;
    private javax.swing.JLabel jLabelTipoR;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}