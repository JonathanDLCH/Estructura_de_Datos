

import javax.swing.JFrame;



public class VideoIntro {
    public static void main (String []args){
        Video obj = new Video();
        obj.setLocationRelativeTo(null);
        obj.setResizable(false);
        obj.setVisible(true);
     
  }
}
