import javax.swing.*;
/*
Software: Grafos
Finalidad:
Realizar Grafos de manera grafica, las funciones implementadas son:
-Crear Grafos Dirigidos y no dirigidos
-Obtener la Matriz de Adyacencia
-Obtener la Matriz de Costos
-Recorrido en Profundidad
-Recorrido en Anchura
*/
public class GrafoTest{

    public static void main(String[] args) {
        
        Grafo grafo = new Grafo(); //Instanciamos el grafo
        GrafoUI frame = new GrafoUI(grafo); //Instanciamos la ventana
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
