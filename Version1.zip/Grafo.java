import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;

/**
 *
 * @author Yalu Galicia Hdez
 *   Estructuras de Datos  
 *   Actualizzado: 2011, 2016
 * Modelo del grafo
 */

class Grafo {
	private int orden; //orden del grafo
	private ArrayList <Vertice> vertices; 
	private Arista [][]M;  //matriz de adyacencia
        //public static int nAristas = 0;  //contador  de aristas
	
	
	public Grafo(){
            this(10);
	}
	
	public Grafo(int orden){
            this.orden = orden;
            vertices = new ArrayList<> ();
            M = new Arista[orden][orden];
	}

	public void agregarVertice(Point2D p){		
            Vertice v = new Vertice(p);
            vertices.add(v); //Se agrega al array
            System.out.println(this.mostrarVertices());
	}

        public void agregarVertice(Point2D p, String nombre){		
            Vertice v = new Vertice(p,nombre);
            vertices.add(v); //Se agrega al array
            System.out.println(this.mostrarVertices());
        }

	//obtiene el primer Vertice que contenga el punto p
	public Vertice getVertice(Point2D p)
	{
            for(Vertice v: vertices)
		if(v.getCirculo().contains(p)) return v;
            return null;
	}

	
	public void agregarArista(Point2D po, Point2D pd){
            //TODO: crear una arista y agregarla a la matriz
            //donde corresponde de acuerdo a los vertices
            // po y pd, son los puntos origen de los vertices
            Arista a = new Arista(po,pd);
            Vertice vo,vd;
            vo = getVertice(po); //obtenemos los vertices
            vd = getVertice(pd);
            M[vo.getIndex()][vd.getIndex()] = a; //se asigna la arista
            M[vd.getIndex()][vo.getIndex()] = a; //se asigna la arista /se agrega en ambos sentidos ya que no es dirigido.
            //nAristas++;
	}
        
        public void agregarArista(Point2D po, Point2D pd,double peso){
            //TODO: crear una arista y agregarla a la matriz
            //donde corresponde de acuerdo a los vertices
            // po y pd, son los puntos origen de los vertices
            Arista a = new Arista(po,pd,peso);
            Vertice vo,vd;
            vo = getVertice(po); //obtenemos los vertices
            vd = getVertice(pd);
            M[vo.getIndex()][vd.getIndex()] = a; //se asigna la arista
            M[vd.getIndex()][vo.getIndex()] = a; //se asigna la arista /se agrega en ambos sentidos ya que no es dirigido.
            //nAristas++;
	}
	
         //mostrar la lista de vertices
        public String mostrarVertices(){
            String cad = " ";
            for(Vertice v: vertices) 
                cad += v.getNombre()+", ";
            return cad;
        }   

	public void dibujar(Graphics2D g2, JPanel l){
       //pintamos los vertices
            for(int i=0;i<orden;i++){
                for(int j=0;j<orden;j++){
                    if(M[i][j]!=null){
                        M[i][j].dibujar(g2);
                    }
                }
            }
            
            for(Vertice v: vertices) {
                v.dibujar(g2);
            }
	}
} //clase