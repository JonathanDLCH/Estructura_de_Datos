import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

/**
 *
 * @author Yalu Galicia Hdez.
 *	Estructuras de Datos
 *      Actualizado: 2019
 */
public class GrafoUI extends JFrame {

	private JPanel pLetrero;
 	private Lienzo lienzo;
	private Grafo grafo; //referencia al grafo

      //constructor
    public GrafoUI(Grafo grafo) {

        super("App Grafo");
        setLocation(450, 100);
        setLayout(new BorderLayout(2,2));

	this.grafo = grafo; //Se conoce el grafo
	lienzo = new Lienzo(this.grafo); //pasamos al grafo para que el liezo lo conozca
        lienzo.setPreferredSize(new Dimension(600, 500));
	initComponentes();
        pack();
   }


    private void initComponentes(){

	    pLetrero = new JPanel();
            pLetrero.add(new JLabel ("Da click en cualquier punto para agregar vertices..."));
            add(pLetrero, BorderLayout.PAGE_START);
            add(lienzo,BorderLayout.CENTER );
    }
}
