import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

class Vertice {
	double x, y;
	Point2D origen;
	Ellipse2D nodo;
	Color color;
	int diametro = 40;
	public static int n = 0;
	
	
	public Vertice(){
		this(null, "x");
	}
	
	public Vertice(Point2D p, String nom){
		x = p.getX();
		y = p.getY();
		origen = p;
		color = Color.blue;
		nodo = new Ellipse2D.Double(x-diametro/2,y-diametro/2,
		    diametro,diametro);
	}
	
	public Vertice(Point2D p){
		this(p, "");
	}
   
   public void setColor(Color c){
   	 color = c;
   }
   
   public void dibujar(Graphics2D g2){
   	 	g2.setPaint(color);
   	 	g2.fill(nodo);
   }
}