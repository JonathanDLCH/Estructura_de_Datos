import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.util.*;

/**
 * Interfaz (Vista)
 *
 * Elabor0: Yalu Galicia Hdez.
 * Revision: Primavera 2019
 *
 */

public class ColoresFr extends JFrame {
	JPanel pBotones, pLetrero;
	JButton btLimpiar, btSalir, btColorear, btRestaurar;
	JLabel lbEtiqueta;
 	 Lienzo lienzo; //panel de dibujo
	//esta declaracion solo es temporal, para ejemplificar
	//colorear y en lugar del TDA grafo
	ArrayList <Vertice> vertices;
	//Creamos un HILO de ejecucion (Thread) para
	//colorear los nodos
	ThreadColores hilo;
    
    //constructor
    public ColoresFr() {
        super("Ejemplo coloreado de vertices");
	setLocation(100, 150);
	setSize(500, 400);

	//temporal
	vertices = new ArrayList <> ();
	lienzo = new Lienzo(vertices);

		//instanciamos componentes
        pBotones = new JPanel();
        pLetrero = new JPanel();
	lbEtiqueta = new JLabel ("Da click en cualquier punto ...");
	btLimpiar = new JButton("limpiar");
	btLimpiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                vertices = new ArrayList <Vertice> ();
                lienzo.setVertices(vertices);
                lienzo.repaint();
          }});
        
        btColorear = new JButton("Colorear");
	btColorear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
		colorear();
            }});

	btRestaurar = new JButton("Restaurar");
	btRestaurar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
		lienzo.restaurar();
            }});

	btSalir = new JButton("Salir");
	btSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               System.exit(0);
            }});

	pBotones.add(btColorear);
	pBotones.add(btRestaurar);
	pBotones.add(btLimpiar);
	pBotones.add(btSalir);
	pLetrero.add(lbEtiqueta);
	add(pLetrero, BorderLayout.NORTH);
	add(lienzo,BorderLayout.CENTER );
	add(pBotones, BorderLayout.SOUTH);
    }

	// OJO: Metodo usado para arrancar el hilo
	public void colorear(){
		//instanciamos un  hilo
		hilo = new ThreadColores(lienzo, vertices);
		//el metodo start() llama al m�etodo RUN del thread
		//a partir de aqui hay dos hilos de ejecucion corriendo
		hilo.start(); //ver clase ThreadColores
	}

	public static void main(String[] args) {
            ColoresFr frame = new ColoresFr();
            frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        }
}
