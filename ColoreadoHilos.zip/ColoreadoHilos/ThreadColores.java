import java.awt.*;
import java.util.*;

/*
 *Esta clase es la que va a permitir colorear los vertices.
 *Recibe como parametro la lista de vertices y el panel(lienzo)
 *donde se dibujan
 */
public class ThreadColores extends Thread {

	private Lienzo lienzo;
	private ArrayList <Vertice> lista;
	private Color[] colores = { Color.RED, Color.red,
	 Color.cyan, Color.yellow, Color.orange,
	 Color.green,Color.LIGHT_GRAY, Color.GRAY,
	 Color.pink, Color.BLACK, Color.DARK_GRAY
	};
	private Color color; //color actual

	public ThreadColores(Lienzo lienzo, ArrayList <Vertice> lista)
	{
		this.lienzo = lienzo;
		this.lista = lista;
		color = Color.yellow; //por default;
	}

	public void run(){
		//obtiene numero aleatorio de 0 a 10
		// y lo relaciona con colores
		color = colores[(int) (Math.random()*10)];
		//para cada vertice, cambia su color y lo dibuja
		for( Vertice v: lista)
		{
			v.setColor(color); //establece nuevo color
			try {
				 /* Repinta los vertices del lienzo
				  * uno a uno cambiando el color
				  * a intervalos de 1 segundos. El metodo
				  * repaint() llama automaticamente
				  * al m�todo paintComponent del lienzo
				  * el cual est� sobreescrito
				  */
				lienzo.repaint();
				sleep(1000);
			}catch (InterruptedException ex){}
		}
	}
}