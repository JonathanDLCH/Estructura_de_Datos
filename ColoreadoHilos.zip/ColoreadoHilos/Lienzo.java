
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

/*
 * * @author  Yalu Galicia Hdez.
 *Lienzo (Panel) para dibujar el grafo
*/

class Lienzo extends JPanel
{

	private Ellipse2D actual;
	private Point2D po, pd;

	public ArrayList <Vertice> vertices;  // para simplicidad

	//constructor
	public Lienzo(ArrayList <Vertice> vertices) {
		setLayout(null); //quitamos gestor de distribucion
		this.vertices = vertices;

		actual = null;
		//agregamos c�digo para que el lienzo "oiga" al raton
		addMouseListener(new MouseAdapter(){
  		  //es llamado cuando se da click sobre el lienzo
		  //sobre se pintan circulos una sola vez
			public void mouseClicked(MouseEvent evento) {
				Point2D x = evento.getPoint();
				if(!existeVertice(x))
					agregarVertice(x);
				repaint();
			}
		});
	} //fin constructor


	//ojo con este metodo, es necesario sobreescribirlo
	//para que se pinte el lienzo.
	public void paintComponent(Graphics g){
		super.paintComponent(g);
	 	Graphics2D g2 = (Graphics2D)g;
	 	setBackground(Color.white);
  	 	//pintamos los vertices
	 	for(Vertice v: vertices){
	 		v.dibujar(g2);
  	 	 }
  	 }


	public void setVertices(ArrayList <Vertice> vertices){
		this.vertices = vertices;
	}

	//AGREGAMOS TEMPORALMENTE estos metodos
	//pero en realidad van en la clase Grafo
	public void agregarVertice(Point2D p){
		double x = p.getX();
		double y = p.getY();
		if(!existeVertice(p)){
			Vertice v = new Vertice(p);
			vertices.add(v);
		}
	}

	public boolean existeVertice(Point2D p){
		for(Vertice n: vertices)
			if(n.nodo.contains(p)) return true;
		return false;
	}

	public Vertice getVertice(Point2D p){
		for(Vertice n: vertices)
			if(n.nodo.contains(p)) return n;
		return null;
	}


	public void restaurar()	{
		for(Vertice v: vertices)
			v.setColor(Color.BLUE);
		repaint();
	}

} //clase Lienzo