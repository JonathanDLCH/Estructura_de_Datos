import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;

/**
 *
 * @author Yalu Galicia Hdez.
 *   Estructuras de Datos  
 *   Actualizzado: 2011, 2016
 * Modelo del grafo
 */

class Grafo {
	private int orden; //orden del grafo
	private ArrayList <Vertice> vertices; 
//	private Arista [][]M;  //matriz de adyacencia
	
	
	public Grafo(){
		this(10);
	}
	
	public Grafo(int orden){
		this.orden = orden;
		vertices = new ArrayList<> ();
	}

	public void agregarVertice(Point2D p){		
		Vertice v = new Vertice(p);
		vertices.add(v);
	}

        public void agregarVertice(Point2D p, String nombre){		
            // ToDO:
        }

	
	//obtiene el primer Vertice que contenga el punto p
	public Vertice getVertice(Point2D p)
	{
		for(Vertice v: vertices)
			if(v.getCirculo().contains(p)) return v;
		return null;
	}

	
	public void agregarArista(Point2D po, Point2D pd){
            //TODO: crear una arista y agregarla a la matriz
            //  donde corresponde de acuerdo a los vertices
            // po y pd, son los puntos origen de los vertices

	}
	
         //mostrar la lista de vertices
        public String mostarVertices(){
            String cad = " ";
            for(Vertice v: vertices) 
                cad += v.getNombre()+", ";
            return cad;
        }   

	public void dibujar(Graphics2D g2, JPanel l){
                
       //pintamos los vertices
	 	for(Vertice v: vertices) 
	 		v.dibujar(g2);
	 	
		//TODO: pintar aristas
		//Tener cuidado! solo pintar aristas existentes!
	}
} //clase