
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jonathan
 */
public class TestCola {
    
    public static void main(String[]args) throws VaciaException{
        int opc,dato,nuevo;
        Cola pCola=new Cola(5);
        Scanner in= new Scanner(System.in);
        
        do{
            System.out.println("0)Salir\n1)Tamaño de la cola\n2)encolar\n3)desencolar\n4)Espiar\n5)Mostrar\n6)Remplazar");
            opc=in.nextInt();
            switch(opc){
                case 0: System.out.println("Gracias por usar la cola.");
                    break;
                case 1: System.out.println(pCola.getNumElementos());
                    break;
                case 2: 
                    System.out.println("Dato a encolar: ");
                    dato=in.nextInt();
                    pCola.queue(dato);
                    break;
                case 3: 
                    try{
                        System.out.println(pCola.dequeue());
                    }catch(VaciaException e){
                        e.getMessage();
                    }
                    break;
                case 4: System.out.println(pCola.peek());
                    break;
                case 5: pCola.mostrar();
                    break;
                case 6: 
                    System.out.println("Que elemento desea remplazar: ");
                    dato=in.nextInt();
                    System.out.println("Que dato sustituira el valor: ");
                    nuevo=in.nextInt();
                    pCola.cambiar(dato, nuevo);
                    break;
                default: System.out.println("Opcion invalida");
            }
        }while(opc!=0);
    }
}
