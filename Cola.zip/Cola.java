/**
 *
 * @author jonathan
 * Cola circular
 */
public class Cola {
    private int valores[]; //Estructura
    private int max; //capacidad de la cola
    private int frente; //Indicadores
    private int numElementos; //Tamaño de la cola
    
    public Cola(){
    this.max=10;
    this.valores=new int[max];
    this.frente=0;
    this.numElementos=0;
    }
    
    public Cola(int t){
        this.max=t;
        this.valores=new int[max];
        this.frente=0;
        this.numElementos=0;
    }
    
    public int getNumElementos(){
        return numElementos;
    }
    
    public boolean  estaVacia(){
        return numElementos==0 && frente==numElementos;
    }
    
    public boolean estaLLena(){
        return numElementos==max;
    }
    
    public void queue(int dato){
        if(!estaLLena()){
            int ubicacion = (frente+numElementos)%max; //Se obtiene la ubicacion del lugar a insertar
            valores[ubicacion]= dato;
            System.out.println("Frente"+frente+", n"+numElementos+", maximo"+max+", ubicacion"+ubicacion);
            numElementos++; //Se incrementa el numero de elementos o final
        }else{
            System.out.println("La cola esta llena.");
        }
    }
    
    public int dequeue()throws VaciaException{
        int dato;
        if(!estaVacia()){
            dato=valores[frente];
            frente=(frente+1)%max;
            numElementos--;
            return dato;
        }else{
            throw new VaciaException("La cola esta Vacia");
        }
    }
    
    public int peek()throws VaciaException{
        int dato;
        if(!estaVacia()){
            dato=valores[numElementos-1];
            return dato;
        }else{
            throw new VaciaException("La cola esta Vacia");
        }
    }
    
    public void mostrar()throws VaciaException{ //Solo para pruebas
        if(!estaVacia()){
            for(int i=frente;i<numElementos;i++){
                System.out.println("|"+valores[i]+"|"); 
            }
        }else{
            throw new VaciaException("La cola esta Vacia");
        }
    }
    
    public void cambiar(int buscar,int remplazo) throws VaciaException{
        int ban=0;
        if(!estaVacia()){
            for(int i=frente;i<numElementos;i++){
                if(valores[i]==buscar){
                    valores[i]=remplazo;
                    System.out.println("Se cambio el valor.");
                    ban++;
                }
            }
        }else{
            throw new VaciaException("La cola esta Vacia");
        }
        if(ban==0){
            System.out.println("No se encontro el elemento");
        }
    }
}
