
import java.util.Scanner;

/**
 * @author jonathan
 */
public class TestPila {
    public static void main(String args[]){
        Scanner entrada= new Scanner(System.in);
        int menu,tam,dato;
        
        System.out.println("Pila");
        System.out.println("Cuantos elementos tendra la pila: ");
        tam = entrada.nextInt();

        Pila myLifo = new Pila(tam);
            
        do{
            System.out.println("1)Push\n2)Pop\n3)Peek\n4)Mostrar Pila\n5)Salir");
            menu = entrada.nextInt();
            switch(menu){
                case 1:
                    if(!myLifo.estaLLena()){
                            System.out.println("Ingrese un dato entero: ");
                            dato= entrada.nextInt();
                            myLifo.push(dato);
                    }else{
                        System.out.println("La pila esta llena");
                    } 
                    break;
                case 2: 
                    if(myLifo.estaVacia()){
                        System.out.println(myLifo.pop());
                    }else{
                        System.out.println("La pila esta vacia");
                    }
                    break;
                case 3: System.out.println(myLifo.peek());
                    break;
                case 4: myLifo.mostrar();
                    break;
                case 5: System.out.println("Gracias por usar la pila");
                    break;
                default: System.out.println("Error de valor");
            }
        }while(menu != 5);
        
        
    }
}
