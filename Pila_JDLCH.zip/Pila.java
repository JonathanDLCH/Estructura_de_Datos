/**
 * @author jonathan
 */
public class Pila {
    
    //Atributos
    private int[] vPila;
    private int max=0,tope=0;
    
    public Pila(int tam){
        vPila = new int[tam];
        max=0;
        tope=tam;
    }
    
    public boolean estaVacia(){ //Indica si esta vacia la pila
        return max<0;
    }
    
    public boolean estaLLena(){ //Indica si esta llena la pila
        return max==tope;
    }
    
    public void push(int dato){
        vPila[max]= dato;
        if(max<tope){
           max++;
        }else{
            if(max>=tope){
                max=tope;
            }
        }
    }
    
    public int pop(){
        int pop=0;
        pop = vPila[max];
        vPila[max]=0;
        if(max>0){
            max--;
        }else{
            max=0;
        }
        return pop;
    }
    
    public int peek(){
        int peek=0;
        if(max<0){
            estaVacia();
        }else{
            peek = vPila[max];
        }
        return peek;
    }
    
    public void mostrar(){
        for (int i = 0; i < vPila.length; i++) {
            System.out.println(vPila[i]);
        }
    }
}
