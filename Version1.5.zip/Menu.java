
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author jonathan
 */
public class Menu extends JPanel implements ActionListener{
    public JLabel lbTitulo;
    public JButton btMatriz,btBFS,btDFS,btAyuda,btDijsktra;
    public JPanel pOpciones;
    public String ayuda;
    private Grafo grafo;
    private Lienzo lienzo;
    public String verticeInicial;
    private ThreadColores hilo;
    private ArrayList <Vertice> verticesdibujar;
    
    public Menu(Grafo grafo,Lienzo lienzo){
        this.grafo=grafo;
        this.lienzo=lienzo;
        this.setLayout(new BorderLayout());
        initComponents();
        ayuda = "               \tSoftware: Grafos\n\n" +
        "Finalidad:\n" +
        "Realizar Grafos de manera grafica, las funciones implementadas son:\n" +
        "   -Crear Grafos Dirigidos y no dirigidos\n" +
        "   -Obtener la Matriz de Adyacencia\n" +
        "   -Obtener la Matriz de Costos\n" +
        "   -Recorrido en Profundidad\n" +
        "   -Recorrido en Anchura\n"+
        "   -Algoritmo de Dijkstra\n"+
        "   -Algoritmo de Bellman-Ford\n\n"+
        "       \tDeveloped by jonathan DLCH 201731754";
    }
    
    private void initComponents(){
        
        lbTitulo= new JLabel("MENU");
        lbTitulo.setFont(new Font("Tahoma", Font.BOLD, 40));
                
        btMatriz = new JButton("Matriz Adyacencia");
        btMatriz.addActionListener(this);
        
        btBFS = new JButton("Recorrido Profundidad");
        btBFS.addActionListener(this);
        
        btDFS = new JButton("Recorrido Anchura");
        btDFS.addActionListener(this);
        
        btAyuda = new JButton("Ayuda");
        btAyuda.addActionListener(this);
        
        pOpciones = new JPanel();
        pOpciones.setLayout(new GridLayout(4,1));
        pOpciones.add(btMatriz);
        pOpciones.add(btBFS);
        pOpciones.add(btDFS);
        pOpciones.add(btAyuda);
        
        
        add(lbTitulo,BorderLayout.NORTH);
        add(pOpciones,BorderLayout.CENTER);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==btMatriz){
            grafo.matrizAdyacencia();
        }
        if(e.getSource()==btBFS){
            try{
                grafo.restablecerVisitados();
                verticeInicial=JOptionPane.showInputDialog("Vertice inicial: ");
                JOptionPane.showMessageDialog(null, grafo.dfs(verticeInicial, ""));
                colorear();
            }catch(Exception ae){
                JOptionPane.showMessageDialog(null, "Error");
            }
        }
        if(e.getSource()==btDFS){
            try{
                grafo.restablecerVisitados();
                verticeInicial=JOptionPane.showInputDialog("Vertice inicial: ");
                JOptionPane.showMessageDialog(null, "BFS");
            }catch(Exception ae){
                JOptionPane.showMessageDialog(null, "Error");
            }
        }
        if(e.getSource()==btAyuda){
            JOptionPane.showMessageDialog(null, ayuda, "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public void colorear(){
        hilo = new ThreadColores(lienzo,verticesdibujar);
        hilo.run();
    }
}
/*
Bibliografia
https://serprogramador.es/programando-mensajes-de-dialogo-en-java-parte-1/
*/
