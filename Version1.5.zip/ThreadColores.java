import static java.lang.Thread.sleep;
import java.util.ArrayList;
import javafx.scene.paint.Color;

/**
 * 
 * @author De La Cruz Huerta Jonathan <201731754>
 */

public class ThreadColores {
    private Lienzo lienzo;
    private ArrayList <Vertice> lista;
    private Color[] colores = {Color.GOLD,Color.SILVER};
    private Color color;
    
    public ThreadColores(Lienzo lienzo,ArrayList <Vertice>lista){
        this.lienzo=lienzo;
        this.lista=lista;
        color=Color.YELLOW;
    }
    
    public void run(){
        color=colores[(int) (Math.random()*1)];
        
        for(Vertice v: lista){
            v.setColor(color);
            try{
                lienzo.repaint();
                sleep(1000);
            }catch(InterruptedException ex){}
        }
    }
}
