import java.awt.*;
import java.awt.geom.*;

class Vertice {
    private String nombre;
    private int index;
    private boolean visitado;
    public static int nVertices = 0;  //contador  de vertices creados
    //Atributos Graficos
    private Point2D origen; //punto origen
    private Ellipse2D circulo;  //circulo
    Color color;
    private final static int diametro = 60;
    private Font fuenteVertice = new Font("FreeMono",Font.PLAIN,18);
	
    public Vertice(){
        this(new Point2D.Double(0,0));
    }

    public Vertice(Point2D p){
        this(p, ""+(nVertices+1));
    }
   
    public Vertice(Point2D p, String nombre){
        double x = p.getX();
        double y = p.getY();
        origen = p;
        color = Color.cyan;
        circulo = new Ellipse2D.Double(x-diametro/2,y-diametro/2,diametro,diametro);
        this.nombre = nombre;
        this.index =nVertices++;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public boolean isVisitado() {
        return visitado;
    }
    public void setVisitado(boolean visitado) {
        this.visitado = visitado;
    }
    public void setColor(Color c){
   	color = c;
    }
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }
   
   public void dibujar(Graphics2D g2){
   	g2.setPaint(color);
   	g2.fill(circulo); //dibujar lleno
    	g2.setPaint(Color.BLACK);
        g2.setFont(fuenteVertice); //Cambia la fuente
        g2.drawString(this.getNombre(), (float)this.origen.getX()-5 , (float) this.origen.getY()+3); //Escribimos en el vertice
   }

    public Ellipse2D getCirculo() {
        return circulo;
    }
    public void setCirculo(Ellipse2D circulo) {
        this.circulo = circulo;
    }
    public Point2D getOrigen(){
        return origen;
    }

    void setColor(javafx.scene.paint.Color color) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
} //fin clase vertice